## BudgetApp

![Screenshot of website](https://github.com/shubhraagarwal/BudgetApp/blob/master/Screenshot2.png)
![Screenshot after entering data](https://github.com/shubhraagarwal/BudgetApp/blob/master/Screenshot1.png)

- [About](#about)
- [Website](https://gouri-panda.github.io/BudgetApp/)
- [How to use](#how-to-use)
- [Contributing](#contributing)
- [Connect](#connect)

## About
BudgetApp has a free web app that helps you track your cash, discover new ways to save, and even build. To remain unbiased we chose not to include ourselves in the list below, but we think you’ll love us anyway.

## How To Use
1. Fork, Clone and Remote
2. Open project in Visual studio code or sublime text
3. Now you are ready to get started 🎉 

## Contributing
Get started with this simple and easy to follow project , it doesn't matter whether you are a beginner or a pro in web-development and open source !
We are always here to help you out and get started . </br>

Find a issue and then solve  the isssue and make a pull request to the repo. If you didn't find any helpful issue for you then raise a issue and start solving the issue.If you like this project please give a star that would help us to motivate for this project.

## Connect
- [Slack Channel](https://join.slack.com/t/newworkspace-uco4265/shared_invite/zt-huokfrna-unLOpo_bo7fKACHZ2rH7jA)
